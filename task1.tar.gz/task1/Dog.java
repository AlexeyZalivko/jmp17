/**
 * Created by alex on 04.02.17.
 */
public class Dog implements Animal {
    @Override
    public void play() {
        System.out.println("dog play");
    }

    @Override
    public void voice() {
        System.out.println("gav!");
    }
}
