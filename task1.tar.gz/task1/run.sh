#!/bin/bash
#java -verbose:class -cp . Main
java -cp . Main
