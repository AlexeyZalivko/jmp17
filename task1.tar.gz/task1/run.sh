#!/bin/bash
#java -verbose:class -cp . Main
java -cp log4j.jar:. Main
