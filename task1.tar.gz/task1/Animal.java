/**
 * Created by alex on 04.02.17.
 */
public interface Animal {

    String play();

    String voice();
}
