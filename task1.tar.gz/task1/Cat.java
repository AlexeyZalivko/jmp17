/**
 * Created by alex on 04.02.17.
 */
public class Cat implements Animal {
    @Override
    public void play() {
        System.out.println("cat play");
    }

    @Override
    public void voice() {
        System.out.println("meow");
    }
}
