#!/bin/bash
rm ./*.class
rm ./*.txt
