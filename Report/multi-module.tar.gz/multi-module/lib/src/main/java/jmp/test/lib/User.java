package jmp.test.lib;

import lombok.Data;

/**
 * Created by Alex on 23.04.2017.
 */
@Data
public class User {
    private Long id;
    private String login;
    private String mail;
}
