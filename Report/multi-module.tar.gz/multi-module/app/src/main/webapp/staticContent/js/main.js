var fun = function () {
    alert("Test")
}